# OR Safety Intelligence V2.3 · FY2570

ระบบรายงานอุบัติการณ์ความปลอดภัยห้องผ่าตัด ประจำปีงบประมาณ 2570 (1 ตุลาคม 2569 – 30 กันยายน 2570) พร้อมข้อมูลย้อนหลัง FY2569 ใน **Google Sheets ใหม่แยกต่างหาก**

## สถานะการส่งมอบ (23 ตุลาคม 2569)

- **Web App:** HTML/CSS/ES Modules แบบ responsive ไม่ใช้ package ภายนอก เปิด demo ได้ มีหน้า Dashboard, Incident CRUD, Risk Profile, Data Quality, Source Validation, PDF Library, CPS Code, Indicators, RCA, Report Builder, Analytics, Settings & Audit
- **Netlify Functions:** server API สำหรับตรวจ Google Identity Token, RBAC, Google Sheets, PDF Drive upload/download/soft-delete, Audit
- **Excel:** `database/OR_Safety_Intelligence_V23_FY2570_Database.xlsx` มี 20 ชีต (19 schema + dictionary) seed Master แบบไม่มีข้อมูลผู้ป่วยจริง
- **Google Sheets จริง:** [OR Safety Intelligence V2.3 FY2570 - NEW DATABASE](https://docs.google.com/spreadsheets/d/1Zvxjq-T2YCJ38dM26kuamTnY2oQBLGAwk0kYnkDvhZs/edit) 20 แท็บ; FY2569 migrated 28 records; Risk Profile 31 pending annual review; legacy archives 28; PDF metadata 2 read-only
- **Reporting:** Preview, select periods/sections/charts, print to A4/PDF, download standalone XLSX/CSV
- **Not live on Netlify:** ต้องให้เจ้าของตั้งค่า Netlify Site, Google Cloud OAuth, Service Account, Private Drive folder และสิทธิ์ก่อน ไม่ได้ทดสอบข้อมูลจริงผ่าน production backend เพราะไม่มี credentials

## Technical decision: dependency-free frontend

แม้สเปกเริ่มต้นระบุ React + Vite แต่ชุดนี้ใช้ **ES Modules + CSS + browser DOM โดยไม่มี npm dependency** เพื่อให้สามารถ build และทดสอบได้จริงในสภาพแวดล้อมที่ไม่สามารถเชื่อม npm registry; `npm run build` เตรียม `dist` และ Netlify Functions ได้ ผลลัพธ์ใช้งานได้ผ่านเบราว์เซอร์เหมือน SPA แต่ **ไม่ได้อ้างว่าเขียนด้วย React/Vite** หากต้องการ React/Vite โดยเคร่งครัด ให้แปลง frontend โดยรักษา API contract ที่มีอยู่

## เริ่มทดลองทันที

```bash
npm run build
npm run dev
# เปิด http://localhost:4173 (demo เท่านั้น)
```

**DEMO = ข้อมูลสมมติ ไม่เชื่อม Google Sheets** ข้อมูลในเบราว์เซอร์ demo อาจถูกลบเมื่อ clear storage/private mode ห้ามใส่ HN หรือรายละเอียดที่ระบุตัวผู้ป่วยใน demo

## Deploy พร้อม Cloud Backend

1. `npm run build`, ควรผ่าน `npm test`
2. สร้าง Google Cloud OAuth Client แบบ Web App พร้อม Authorized JavaScript origin เป็น Netlify URL ที่จะใช้
3. เปิด Google Sheets API และ Google Drive API ใน Google Cloud Project
4. สร้าง Service Account / Domain-wide Delegation ที่ได้รับการอนุมัติ
5. แชร์ Google Sheet ใหม่ให้ service account ตามสิทธิ์จำเป็น **เฉพาะใหม่** ไม่เขียนทับ V2.1
6. สำหรับ PDF ให้มี **private Shared Drive folder** ที่ Service Account เขียนได้ (service account โดยทั่วไปไม่มีพื้นที่ส่วนตัวสำหรับอัปโหลดบน My Drive ของผู้ใช้); ตั้ง `GOOGLE_DRIVE_FOLDER_ID`
7. ใส่ Environment Variables จาก `.env.example` ใน Netlify Site Settings (server-side เท่านั้น)
8. ใส่ `ADMIN_EMAILS` เป็นอีเมลที่ได้รับอนุญาต อย่างน้อย 1 คน; จัดการ USERS sheet เพิ่ม user ที่ควรเข้าถึง
9. Deploy Git/Netlify CLI: `npx netlify-cli deploy --build --prod` บนเครื่องที่เข้าถึง npm/CLI ได้ หรือใช้ Netlify เชื่อม Git repository; **ไม่ใช่ Netlify Drop แบบ static-only**
10. ตรวจ `/api/?action=config` ตอบ `configured: true`, ลงชื่อเข้าใช้ และทดสอบ Create/Update/PDF บนรายการจำลองก่อนใช้ข้อมูลจริง

อ่าน `docs/Netlify_Deployment.md`, `docs/Google_Sheets_Setup.md`, `docs/Security_Checklist.md`

## Fiscal Year

- FY2569 = 2025-10-01 ถึง 2026-09-30
- FY2570 = 2026-10-01 ถึง 2027-09-30
- Dropdown แสดง 2570 เป็นค่าเริ่มต้น / เลือก FY2569 ย้อนหลังได้
- ใช้ Date ของเหตุการณ์ ไม่ใช่ Created_At

## FY2569 Migration ที่ดำเนินการแล้ว

Google Sheets ใหม่: 28 incidents / 28 legacy archive snapshots / 31 risk profiles pending review / 10 RCA cases / 2 pending indicator classifications / 1 linked source index / 2 metadata PDF read-only.

ต้นฉบับ V2.1 **ไม่ถูกเปลี่ยน**. Original PDF bytes ยังอยู่ใน Drive ต้นฉบับ, PDF metadata ใน V2.3 ทำหน้าที่อ้างอิงเท่านั้น. เมื่อเชื่อม Private Drive ใหม่อาจต้องขอสิทธิ์หรือคัดลอกไฟล์หากต้องการดาวน์โหลดไฟล์เก่า.

## การ Export รายงาน

เปิด Reports → เลือกรายเดือน/รายไตรมาส/รายปี → เลือกผู้รับ → เลือกหัวข้อและกราฟ → ตรวจ Preview → กด Print / Save as PDF หรือส่งออก XLSX/CSV. Browser PDF มีขนาด A4, แยกหน้าอัตโนมัติ, ฟอนต์ใช้ Sarabun/Noto Sans Thai ตามเครื่องผู้พิมพ์. ชุด demo มีตัวอย่าง PDF ให้ดูใน docs.

## ข้อจำกัดความพร้อมจริง

1. ไม่ได้ทดสอบ end-to-end บน Netlify/Google Cloud ตัวจริงเพราะผู้ใช้ต้องกำหนด OAuth และ Service Account ด้วยสิทธิ์ขององค์กร
2. Google Sheets API เป็น **ไม่ใช่ transactional database**: การเขียนพร้อมกันหลายเครื่องมี optimistic revision check แต่ไม่ใช่ atomic compare-and-swap 100%. ก่อนเปิดใช้หลายผู้ใช้พร้อมกันในระบบสำคัญควรใช้ transactional backend หรือ centralized locking
3. PDF Cloud upload จำกัด 4 MB เพื่อควบคุมขนาด request; หากต้องการไฟล์ใหญ่ควรเปลี่ยนเป็น resumable upload แบบ server-authenticated
4. Source classifications/SSI ของ FY2569 ที่อนุมานจากข้อมูลเดิมถูกตั้ง **Pending** รอตรวจสอบ เพื่อไม่สร้าง KPI หลอก
5. ต้องผ่านการตรวจ PDPA/HA และทดสอบสิทธิ์ penetration/basic security review ก่อนใช้กับข้อมูลอ่อนไหว
6. Report email delivery ไม่ได้เปิดใช้โดยอัตโนมัติ: ผู้ใช้ดาวน์โหลด PDF แล้วส่งด้วยช่องทางที่โรงพยาบาลอนุมัติ
7. รูปแบบไฟล์ Excel ใน browser เป็น XLSX จริงแบบ lightweight; ไม่มี pivot/formatting ขั้นสูง

© OR Safety Intelligence V2.3 — Private hospital usage only.

## Historical fiscal-year entry (patch 2026-10-23)
- Incident Date accepts any valid calendar date. Fiscal year is derived from the incident date, rather than save date.
- Fiscal year dropdowns now list FY2558–FY2572 and additionally any fiscal years found in existing Incident rows, preserving access to older backfilled events.
- Monthly report captions show the Thai calendar year (e.g. Oct 2569) and the fiscal year separately (FY2570).
- CPS catalog is managed in CPS_MASTER; set Active=FALSE to retire a code without deleting historical references. Refresh the web app after master changes.
- Cloud editing and persistent saving require Google/Netlify authentication and live API configuration; standalone demo edits are browser-local only.

## V2.3 Report Builder — final UI release

**Deliverable update:** Report setup follows the approved cream/dark-green/pink screenshot, without changing the rest of the app. Options: monthly, quarterly, annual, full FY, multi-month, custom date; multi-recipient labels; selectable individual/all/none report sections and charts; live scrollable A4 preview; PDF via browser print, XLSX data tables, CSV, first supported SVG chart to PNG. Excel template includes `REPORT_BUILDER_GUIDE`.

**FY2569 data:** copied previously into the separate live Google Sheet (`1Zvxjq-T2YCJ38dM26kuamTnY2oQBLGAwk0kYnkDvhZs`); not embedded in this downloadable XLSX for patient privacy. Old V2.1 sheet is not modified by this release.

**Production prerequisites:** Install/configure Google Identity Services, Service Account permissions, private Drive folder and Netlify Functions; **do not** treat successful local DEMO tests as live Google/Netlify integration. See docs/Report_Builder_Guide.md.
