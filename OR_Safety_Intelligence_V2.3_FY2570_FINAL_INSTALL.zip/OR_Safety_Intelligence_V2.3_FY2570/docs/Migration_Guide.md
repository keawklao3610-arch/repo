# FY2569 Migration Record (verified)

New target: `1Zvxjq-T2YCJ38dM26kuamTnY2oQBLGAwk0kYnkDvhZs`
Legacy source (unchanged): `1TjqB8ALm38j8bSbaoVY1g4X9dkrrL_G5zdyE9-vYonc`
FY2569 date: 2025-10-01 through 2026-09-30 (source Date field)

Confirmed migration using connected Google Drive tool:
- 28 Incident records into new `INCIDENTS`
- 28 full raw-row snapshots into `LEGACY_ARCHIVE`
- 31 Risk Profiles (marked `Pending Annual Review`)
- 10 RCA case records as mapped from legacy
- 2 indicator assignments tagged `Pending` (NOT confirmed until clinical verification)
- 1 linked Source Index record
- 2 old PDF metadata rows set `Legacy / read-only` (file bytes still in original Drive; access unverified)
- 1 migration ledger entry in `MIGRATION_LOG`

These rows remain private in Google Sheets. **No patient incident narrative is placed in the downloadable ZIP/XLSX.**

The CLI migration script `npm run migrate:2569` is for future recovery and requires Cloud credentials; do not rerun casually after manual edits. Original source is never overwritten.

Clinical verification required: Severity A–I validity, CPS code definitions, Risk mapping and SSI/other indicator confirmation. Legacy PDF metadata does not grant access to source file contents.
