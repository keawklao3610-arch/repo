# คู่มือผู้ใช้งานย่อ V2.3

1. ลงชื่อเข้าใช้ด้วย Google Account ที่ได้รับอนุญาต (`DEMO` ไม่ใช่ระบบจริง)
2. Dashboard เลือก FY2570, เดือนหรือทั้งปี; คลิก Refresh เมื่อต้องการ Master ล่าสุด
3. Incident → เพิ่มเหตุการณ์ → กรอก Date, CPS/NRLS (ค้นหาจากรหัส), Title, Severity, Detail; Safety Indicator สามารถเลือกหลายตัว แต่ค่าที่แนะนำเป็น Pending เท่านั้น
4. RCA Screening ค่าเริ่ม Pending; ถ้าเลือก Required ช่อง RCA จะเปิดและสามารถกลับมาเติมรายละเอียดภายหลัง
5. Incident List → กด แก้ไข เพื่อเปลี่ยนข้อมูลเดิม, Revision จะเพิ่มพร้อม Audit
6. PDF Library → เพิ่ม PDF (<4 MB) ระบุ Incident ID หากต้องการเชื่อม → เปิด/ดาวน์โหลด → ลบแบบย้ายเข้า Trash และบันทึกเวลา/ผู้ลบ
7. รายงาน → เลือก Monthly/Quarterly/Annual, ผู้รับ, Section และ Graph → ดู Preview → Print / Save as PDF A4 หรือ XLSX / CSV
8. หากเลือก FY2569 จะแสดงประวัติที่ย้ายมา แต่ SSI Pending จะไม่ถูกนับ Confirmed จนกว่าผู้รับผิดชอบยืนยัน
9. Settings (สำหรับผู้ได้รับสิทธิ์) เพิ่มหรือปิดใช้ Master จาก Sheet และกด Refresh

**ข้อควรระวัง:** อย่าพิมพ์ข้อมูลผู้ป่วยจริงในระบบ Demo; PDF/Audit/Sync บน Cloud ต้องผ่านการตั้งค่าและทดสอบสิทธิ์ก่อน.

## หน้ารายงานรูปแบบอนุมัติ V2.3 (อัปเดต)
- เลือกช่วง: Monthly / Quarterly / Annual / Full Fiscal Year / Multi-Month / Custom Date
- เลือกผู้รับหลายราย, เลือก / ยกเลิก Section และ Chart ทั้งหมด, Preview ที่อัปเดตทันที
- Print/Save PDF A4 / Excel .xlsx / CSV / PNG (กราฟแรกที่เป็น SVG)
- Preset ใน `REPORT_TEMPLATES` ของ Google Sheets ใช้เป็นค่าเริ่มต้นหลัง Refresh; โปรดจัดการ Section IDs และ Chart IDs ตามรายการที่โค้ดรองรับ
- รายงานจำนวนเหตุ SSI ที่ Confirmed ไม่ใช่ SSI rate หากยังไม่มีตัวหารที่ตรวจสอบแล้ว
