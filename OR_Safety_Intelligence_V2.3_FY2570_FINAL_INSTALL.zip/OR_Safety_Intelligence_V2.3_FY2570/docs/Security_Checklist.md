# Pre-production Security Checklist

- [ ] โรงพยาบาลอนุมัติใช้ Google Workspace/Netlify/Cloud สำหรับข้อมูลอ่อนไหวหรือไม่
- [ ] มี DPA/ข้อตกลงการประมวลผลและการจัดเก็บข้อมูลสอดคล้อง PDPA หรือไม่
- [ ] Google Sheet V2.3 ใหม่เป็น Private (ไม่แชร์สาธารณะ)
- [ ] Service Account เข้าถึงเฉพาะ Sheet และ Shared Drive folder ที่จำเป็น
- [ ] ตัวแปร GOOGLE_SERVICE_ACCOUNT_JSON อยู่ใน Netlify secret ไม่อยู่ใน Git/HTML/ZIP
- [ ] OAuth origin จำกัด Production HTTPS และ verify Google ID token ทุก API call
- [ ] USERS และ ADMIN_EMAILS อนุญาตเฉพาะเจ้าหน้าที่จริง
- [ ] RBAC ทดสอบ Viewer ไม่สามารถ Create/Update/Delete
- [ ] PDF ห้าม public; ตรวจ upload/download/delete permission
- [ ] PDF เก่า Legacy read-only ห้ามลบไฟล์ V2.1
- [ ] ตรวจ Audit Trail ต่อ Create/Update/Delete/Upload/Master
- [ ] Backup และ Restore ทดลองคืนข้อมูลได้
- [ ] มี Retention Policy สำหรับ incident / attachments / audit
- [ ] เก็บข้อมูลผู้ป่วยเท่าที่จำเป็น ไม่มี HN ใน Report Export เริ่มต้น
- [ ] ทดสอบ Input sanitization/CSV injection/XSS และ rate limits
- [ ] ตรวจ concurrent edit และความครบถ้วนของ write operations (Google Sheets ไม่รองรับ transaction)
- [ ] ให้ทีม IT/สารสนเทศโรงพยาบาลตรวจการ Deploy ก่อนเปิดให้ใช้จริง
