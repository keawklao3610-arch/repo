# คู่มือ Deploy Netlify — OR Safety Intelligence V2.3

## แนะนำ Git-based Deploy

1. สร้าง GitHub repository แบบ PRIVATE และ upload โฟลเดอร์นี้โดยไม่รวม `.env` หรือ credential ใด ๆ
2. เชื่อม Site ใหม่ใน Netlify กับ repository
3. Build command: `npm run build`; Publish directory: `dist`; Functions directory: `netlify/functions`; Node 20+
4. `netlify.toml` ในโปรเจกต์กำหนด redirects `/api/*` → Netlify Function ให้แล้ว
5. ตั้ง Environment Variables: `GOOGLE_SHEET_ID`, `GOOGLE_CLIENT_ID`, `GOOGLE_SERVICE_ACCOUNT_JSON`, `ADMIN_EMAILS`, `GOOGLE_DRIVE_FOLDER_ID` และถ้ามี Google Workspace ใช้ `ALLOWED_GOOGLE_DOMAIN`
6. OAuth Authorized JavaScript Origins ต้องตรงกับ URL ของ Netlify ทั้ง https และ custom domain ที่ใช้
7. Redeploy หลังแก้ Environment Variables; ตรวจสอบ `/api/?action=config` ว่า `configured:true`
8. Google account ที่ไม่ได้อยู่ใน USERS หรือ ADMIN_EMAILS ต้องถูกปฏิเสธด้วย 403

## Netlify CLI (บนเครื่องที่ติดตั้ง CLI ผ่าน npm ได้)

```bash
npm install
npm run test
npm run build
npx netlify-cli login
npx netlify-cli init
npx netlify-cli dev
npx netlify-cli deploy --build --prod
```

CLI อาจมีขั้นตอนเพิ่มเติมตามเวอร์ชัน/สิทธิ์ของบัญชี. หลีกเลี่ยง Netlify Drop สำหรับระบบที่มี server functions, environment secrets และ Google Auth

## ค่าตัวแปร

- `GOOGLE_SHEET_ID=1Zvxjq-T2YCJ38dM26kuamTnY2oQBLGAwk0kYnkDvhZs` (Sheet V2.3 ใหม่)
- `GOOGLE_CLIENT_ID` = OAuth 2.0 client ID ของเว็บ (public ID ไม่ใช่ secret)
- `GOOGLE_SERVICE_ACCOUNT_JSON` = JSON ทั้งชุดของ Service Account (private, Netlify UI server-only)
- `GOOGLE_DRIVE_FOLDER_ID` = Private Shared Drive folder สำหรับไฟล์ PDF ใหม่
- `ADMIN_EMAILS` = อีเมลผู้ดูแล 1 คนขึ้นไปคั่นด้วย comma
- `ALLOWED_GOOGLE_DOMAIN` = โดเมน Google Workspace หากบังคับเข้าระบบด้วย domain นั้น
- `LEGACY_SHEET_ID` = V2.1 ID (ใช้เฉพาะ script migration หากต้อง run อีกครั้ง)

## ตรวจผลการติดตั้ง

- เปิดเว็บ → ระบบต้องขอ Sign In เมื่อ config ครบ (หากยัง demo แสดงว่ายังไม่พร้อม cloud)
- ลงชื่อเข้าใช้ด้วย admin, ตรวจเมนู Settings (ข้อมูล Master จากชีตใหม่)
- Create Incident จำลอง FY2570 → ดูใน Sheet `INCIDENTS` → Edit → Revision เพิ่ม, `AUDIT_LOG` มีประวัติ
- ลอง Confirm SSI → Dashboard SSI เพิ่มเฉพาะ Incident ID ที่ยืนยัน
- Upload PDF ตัวอย่างที่ไม่มีข้อมูลผู้ป่วย → ตรวจใน Drive private folder → Download → Delete soft → file moved to Trash, Metadata Status=Deleted
- ลองรายงาน A4/Excel และตรวจภาษาไทย
- ทดสอบสิทธิ์ Viewer (ไม่สามารถบันทึก/ลบ)

## ติดตั้งแยกปี

ข้อมูล FY2569 28 รายการได้ย้ายเข้าฐาน V2.3 ใหม่แล้ว ตรวจ `MIGRATION_LOG` ก่อนสั่ง `npm run migrate:2569` ซ้ำ (script ตรวจ Incident_ID / Fingerprint เพื่อป้องกัน duplicate).
