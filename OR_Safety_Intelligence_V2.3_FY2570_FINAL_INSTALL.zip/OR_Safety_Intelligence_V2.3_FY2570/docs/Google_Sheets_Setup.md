# Google Sheets Setup / Master Data

**V2.3 Native Sheet:** https://docs.google.com/spreadsheets/d/1Zvxjq-T2YCJ38dM26kuamTnY2oQBLGAwk0kYnkDvhZs/edit

**V2.1 Legacy:** `1TjqB8ALm38j8bSbaoVY1g4X9dkrrL_G5zdyE9-vYonc` (READ ONLY)

ตาราง V2.3 20 แท็บ: SETTINGS, USERS, INCIDENTS, CPS_MASTER, RISK_PROFILE, SAFETY_INDICATORS, CPS_INDICATOR_MAP, INCIDENT_INDICATORS, RCA_CASES, RCA_ACTIONS, SOURCE_INDEX, PDF_ARCHIVE, AUDIT_LOG, KPI_SETTINGS, REPORT_TEMPLATES, REPORT_HISTORY, MONTHLY_DENOMINATORS, RECIPIENTS, LEGACY_ARCHIVE, MIGRATION_LOG

อธิบายความสัมพันธ์: `INCIDENTS.Incident_ID` → `INCIDENT_INDICATORS.Incident_ID`, `RCA_CASES.Incident_ID`, `SOURCE_INDEX.Linked_Incident_ID`, `PDF_ARCHIVE.Linked_Incident_ID`; `INCIDENTS.CPS_Code` → `CPS_MASTER.CPS_Code`; `INCIDENTS.Risk_Profile` → `RISK_PROFILE.Risk_ID`; `CPS_INDICATOR_MAP` → `CPS_MASTER + SAFETY_INDICATORS`; `RCA_ACTIONS.RCA_ID` → `RCA_CASES.RCA_ID`.

## เพิ่ม/ลบตัวเลือก

- เพิ่ม CPS: เพิ่มแถวใน `CPS_MASTER` กำหนดรหัสไม่ซ้ำ ชื่อ/Keywords `Active=TRUE`
- ปิดใช้ CPS: เปลี่ยน `Active=FALSE`, **ห้ามลบแถวที่มี Incident อ้างอิง**
- เพิ่ม Safety Indicator: เพิ่มแถว `SAFETY_INDICATORS` และแมป `CPS_INDICATOR_MAP`
- เพิ่มรายชื่อผู้รับ: `RECIPIENTS` กำหนด `Recipient_ID`, Name และ Active
- สิทธิ์ผู้ใช้: `USERS` Email, Display_Name, Role (`admin`,`risk_manager`,`editor`,`viewer`), Active = TRUE. `ADMIN_EMAILS` สามารถ bootstrap ผู้ดูแลได้
- Risk Profile ที่ย้ายจากปีเก่าตั้ง `Status=Pending Annual Review`; ให้หัวหน้าทบทวนและเปลี่ยน `Active` หลังประเมิน

เว็บดึง Master ใหม่ในปุ่ม Refresh / เมื่อ Reload (ไม่จำเป็นต้อง Deploy ใหม่). ไม่มี Cache ที่แอบแสดงข้อมูลเก่าเป็น Connected

## PDF

ไฟล์ใหม่อยู่ใน PRIVATE Drive Folder ที่ Netlify Service Account มีสิทธิ์ สามารถเพิ่ม ลบ/Trash ผ่านเว็บและเก็บ Audit. PDF Legacy 2 รายการถูกเก็บใน `PDF_ARCHIVE` แบบ `Legacy / read-only` **ไม่อนุญาตให้ลบผ่าน Backend V2.3** เพื่อป้องกันกระทบ V2.1. หากต้องใช้จริงให้คัดลอกไปโฟลเดอร์ใหม่ภายใต้กระบวนการควบคุมเอกสาร.

## Data governance

อย่าแชร์ชีต/โฟลเดอร์เป็น Anyone with the link. ควบคุม sharing กับบัญชีองค์กร. อย่าเก็บ HN/ชื่อผู้ป่วยใน title หรือ Demo. จัดทำนโยบาย retention / backup / audit ตามเกณฑ์โรงพยาบาล.
