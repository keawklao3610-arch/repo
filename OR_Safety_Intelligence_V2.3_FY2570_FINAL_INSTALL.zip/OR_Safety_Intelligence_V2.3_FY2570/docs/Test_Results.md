# QA results — 23 Oct 2026

## PASSED (executed)
- Native FY2570 Google Sheet created separately; 20 tabs verified
- Connected migration: 28 FY2569 incidents; 28 archive snapshots; 31 risks; 10 RCA; 2 PDF metadata; verification read backs
- Node.js unit tests: 9/9 passed
- `node --check` frontend/server code passed
- `npm run build` produced `dist/` from source without external network
- Playwright-rendered Dashboard had exactly six KPI cards and correct SSI third position
- Responsive check 390px viewport (Dashboard and Reports) had no horizontal overflow
- CPS111 autocomplete populated incident title
- Choosing Required RCA rendered RCA fields
- Report Builder preview rendered; XLSX browser download produced real `.xlsx` file

## NOT FULLY VERIFIED / BEFORE PATIENT DATA
- Online OAuth Google sign-in and live Netlify Functions were not end-to-end tested: user must set Google Cloud Client ID and Service Account secret
- Server-side PDF Drive upload/trash needs private Shared Drive folder configuration and permissions
- Real concurrency / transaction safety needs IT validation (Google Sheets is not transactional)
- Browser Save as PDF print layout should be checked on actual Windows/iOS printers and browsers
- Data migration indicator status = Pending until clinical review
- No production Netlify URL yet (deploy requires user account)

## Build instructions
`npm test` → `npm run build` → test demo → configure Cloud env → Netlify deploy → run acceptance on fake records first.
- Playwright demo Create Incident with CPS111 + Conditional RCA → returned to Incident List and edit controls visible
- Playwright demo PDF upload → 1 document visible → Soft Delete → 0 active documents visible
- Mobile form rendered and mobile Report Builder no overflow, JavaScript page errors = 0
- Browser PDF generated at 210x297mm A4 with Thai text; visually checked rendered 3 pages, no clipping detected
- Browser XLSX download validated as genuine ZIP-based Office Open XML, and base database XLSX verified
