/** FY2569 was already migrated into the new 20-tab V2.3 sheet.
 *  This optional script performs a DRY-RUN count without writing legacy data.
 *  For idempotent migration logic see scripts/migrate-2569.mjs.
 */
function previewLegacyFY2569() {
 const sourceId='1TjqB8ALm38j8bSbaoVY1g4X9dkrrL_G5zdyE9-vYonc';
 if(sourceId===SpreadsheetApp.getActiveSpreadsheet().getId())throw Error('Safety: use NEW sheet only');
 const src=SpreadsheetApp.openById(sourceId).getSheetByName('INCIDENTS');
 const values=src.getDataRange().getDisplayValues();
 const header=values[0];const dateIndex=header.indexOf('Date');
 let count=0;for(const row of values.slice(1)){const date=String(row[dateIndex]);if(/^2025-(10|11|12)-/.test(date)||/^2026-(0[1-9])-/.test(date))count++;}
 SpreadsheetApp.getUi().alert('พบ FY2569 จำนวน '+count+' รายการ (DRY RUN; ไม่เขียนข้อมูล)');
}
