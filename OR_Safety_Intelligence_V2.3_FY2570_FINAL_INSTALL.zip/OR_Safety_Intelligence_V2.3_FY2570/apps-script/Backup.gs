/** Run with permission on target. Creates private copy in Drive for recovery. */
function backupV23Spreadsheet() {
 const original = SpreadsheetApp.getActiveSpreadsheet();
 const id = original.getId();
 const stamp = Utilities.formatDate(new Date(),'Asia/Bangkok','yyyy-MM-dd_HHmm');
 const duplicate = DriveApp.getFileById(id).makeCopy('BACKUP_OR_Safety_V23_'+stamp);
 SpreadsheetApp.getUi().alert('Backup created privately: '+duplicate.getName());
}
