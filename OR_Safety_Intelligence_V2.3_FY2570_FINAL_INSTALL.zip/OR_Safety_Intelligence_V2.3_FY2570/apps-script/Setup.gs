/** OPTIONAL: Google Apps Script bound to the NEW FY2570 spreadsheet. */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('OR Safety V2.3')
    .addItem('ตรวจสอบรายการชีต', 'checkV23Sheets')
    .addItem('สร้างสำเนาสำรอง', 'backupV23Spreadsheet')
    .addToUi();
}
function checkV23Sheets() {
  const required = ['INCIDENTS','RISK_PROFILE','CPS_MASTER','SAFETY_INDICATORS','INCIDENT_INDICATORS','RCA_CASES','PDF_ARCHIVE','AUDIT_LOG','LEGACY_ARCHIVE','MIGRATION_LOG'];
  const names = SpreadsheetApp.getActiveSpreadsheet().getSheets().map(x => x.getName());
  const missing = required.filter(x => !names.includes(x));
  SpreadsheetApp.getUi().alert(missing.length ? 'ขาดชีต: '+missing.join(', ') : 'ผ่าน: พบชีตหลักครบ');
}
