/** Report-period calculations use Gregorian ISO dates in Asia/Bangkok's local calendar.
 * Fiscal year is the Buddhist-year label of the Sep 30 endpoint. */
export const fiscalMonths=[10,11,12,1,2,3,4,5,6,7,8,9];
export function fiscalYearOf(iso){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso||''));if(!m)return null;const [,ys,ms,ds]=m;const y=+ys,mo=+ms,d=+ds;const t=new Date(Date.UTC(y,mo-1,d));if(t.getUTCFullYear()!==y||t.getUTCMonth()!==mo-1||t.getUTCDate()!==d)return null;return y+543+(mo>=10?1:0)}
export function reportWindow({period='monthly',year=2570,month=10,quarter=1,months=[],from='',to=''}){
  const f=Number(year);const m=Number(month);const q=Number(quarter);
  const start=`${f-544}-10-01`,end=`${f-543}-09-30`;
  if(period==='custom')return {start:from||start,end:to||end,months:null};
  if(period==='monthly')return {start,end,months:[m]};
  if(period==='multi')return {start,end,months:[...new Set(months.map(Number))].filter(v=>v>=1&&v<=12)};
  if(period==='quarterly')return {start,end,months:fiscalMonths.slice((q-1)*3,q*3)};
  return {start,end,months:null};
}
export function filterReportRecords(records,options){const w=reportWindow(options);if(w.start>w.end)return [];return records.filter(r=>{const d=String(r.Date||'');return d>=w.start&&d<=w.end&&(!w.months||w.months.includes(+d.slice(5,7)))&&r.Status!=='Deleted'});}
export function reportPeriodLabel(opts,monthNames){const p=opts.period||'monthly',f=Number(opts.year),m=Number(opts.month),q=Number(opts.quarter||1);if(p==='monthly')return `ประจำเดือน${monthNames[m-1]} ${m>=10?f-1:f} (FY${f})`;if(p==='quarterly')return `ไตรมาส ${q} ปีงบประมาณ ${f}`;if(p==='multi')return `เดือนที่เลือก (${(opts.months||[]).map(m=>monthNames[m-1]).join(', ')||'ไม่มี'}) ปีงบประมาณ ${f}`;if(p==='custom')return `ตั้งแต่ ${opts.from||'—'} ถึง ${opts.to||'—'}`;if(p==='annual')return `รายงานประจำปีงบประมาณ ${f}`;return `ตลอดปีงบประมาณ ${f} (ต.ค. ${f-1} – ก.ย. ${f})`;}
