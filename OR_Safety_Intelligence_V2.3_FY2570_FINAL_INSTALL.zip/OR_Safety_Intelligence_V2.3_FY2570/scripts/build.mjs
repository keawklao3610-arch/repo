import {mkdir,cp} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
for(const [src,dest] of [['public/index.html','dist/index.html'],['src/styles/style.css','dist/style.css'],['src/app.js','dist/app.js'],['src/services/xlsx.js','dist/xlsx.js'],['src/services/report-periods.js','dist/report-periods.js']]) await cp(src,dest);
console.log('Production static assets built in dist/. Netlify deploys dist/ and netlify/functions/.');
